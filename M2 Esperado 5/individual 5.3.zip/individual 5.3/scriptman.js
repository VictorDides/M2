

var verde = document.getElementById('verde');
var amarillo = document.getElementById('amarillo');
var rojo = document.getElementById('rojo');
var semaforo = document.getElementById('semaforo');
var boton = document.getElementsByClassName('botonsemaforo')


var intervalId;
var mousePosition;



function encenderVerde() {
	rojo.style.backgroundColor = 'black';
	amarillo.style.backgroundColor = 'black';
	verde.style.backgroundColor = 'green';
    
    /*setTimeout(encenderAmarillo, 3000);*/
}

function encenderAmarillo() {
	rojo.style.backgroundColor = 'black';
	amarillo.style.backgroundColor = 'yellow';
	verde.style.backgroundColor = 'black';
    /*setTimeout(encenderRojo, 1000);*/
}

function encenderRojo() {
	rojo.style.backgroundColor = 'red';
	amarillo.style.backgroundColor = 'black';
	verde.style.backgroundColor = 'black';

	/*setTimeout(encenderVerde, 3000);*/
}

/*function activarSemaforo() {
	encenderVerde();
	intervalId = setInterval(cambiarSemaforo, 7000);
}*/

function cambiarSemaforo(event) {
    var distX = (event.clientX - semaforo.offsetLeft - semaforo.offsetWidth) / 2;
    var distY = (event.clientY - semaforo.offsetTop - semaforo.offsetHeight) / 2;
	var mousePosition = Math.sqrt(distX * distX + distY * distY);

	if (mousePosition > 200) {
		encenderVerde();
	} else if (mousePosition >= 150 && mousePosition <= 200) {
		encenderAmarillo();
	} else {
		encenderRojo();
	}
}

document.addEventListener('mousemove', cambiarSemaforo)






