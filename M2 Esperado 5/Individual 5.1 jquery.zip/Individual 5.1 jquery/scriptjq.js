
$("#boton").click(function() {
    var nuevoElemento = $("<li>")
      .text($("#valorInput").val())
      .appendTo($("#lista"));

    nuevoElemento.click(function() {
      nuevoElemento.remove();
    });

    $("#valorInput").val("");
  });



  $("#valorInput").keypress(function() {
    var keycode = event.keyCode || event.which;
    if(keycode == '13') 
    var nuevoElemento = $("<li>")
      .text($("#valorInput").val())
      .appendTo($("#lista"));

    nuevoElemento.click(function() {
      nuevoElemento.remove();
    });

    $("#valorInput").val("");
  });