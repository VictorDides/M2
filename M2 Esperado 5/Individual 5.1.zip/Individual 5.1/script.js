var input = document.getElementById('valorInput')
var button = document.getElementById('boton')
var lista = document.getElementById('lista')

function agrega(){
    var valor = input.value;
    var nuevo = document.createElement('li');
    nuevo.textContent = valor;
    lista.appendChild(nuevo);

}
button.addEventListener('click', agrega);