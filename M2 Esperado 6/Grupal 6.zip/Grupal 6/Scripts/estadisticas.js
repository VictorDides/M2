$(document).ready(function() {
    $('#miTabla').DataTable({
        deferRender:    true,
        scrollY:        200,
        scrollCollapse: true,
        scroller:       true
        });
    
});
